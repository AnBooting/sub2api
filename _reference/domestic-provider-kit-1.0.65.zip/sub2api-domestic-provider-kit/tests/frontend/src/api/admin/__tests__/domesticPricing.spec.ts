import { describe, expect, it } from 'vitest'
import { catalogItems, type DomesticPricingCatalogEntry } from '@/api/admin/domesticPricing'

const entry: DomesticPricingCatalogEntry = {
  provider: 'deepseek',
  model: 'deepseek-v4-pro',
  input_price_per_token: 0.000000435,
  output_price_per_token: 0.00000087,
  source: 'https://api-docs.deepseek.com/quick_start/pricing',
  version: 20260809,
  updated_at: '2026-08-09T00:00:00Z',
  status: 'active',
  peak_rate_multiplier: 2,
  peak_schedule: '工作日 09:00-12:00、14:00-18:00（北京时间）'
}

describe('domestic pricing API response', () => {
  it('unwraps the catalog metadata envelope returned by the admin API', () => {
    expect(catalogItems({
      items: [entry],
      currency: 'USD',
      unit: 'token',
      display_unit: 'million_tokens'
    })).toEqual([entry])
  })
})
