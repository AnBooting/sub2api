import { readFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

import { describe, expect, it } from "vitest";

const source = readFileSync(
  resolve(dirname(fileURLToPath(import.meta.url)), "../GroupBadge.vue"),
  "utf8",
);

describe("GroupBadge domestic user multiplier", () => {
  it("shows group × user while retaining the legacy non-domestic branch", () => {
    expect(source).toContain("hasDomesticUserFactor");
    expect(source).toContain("groupRate * userRate");
    expect(source).toContain('v-else-if="hasCustomRate"');
  });
});
