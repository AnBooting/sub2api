import { defineComponent } from 'vue'
import { mount } from '@vue/test-utils'
import { describe, expect, it, vi } from 'vitest'
import GroupSelector from '@/components/common/GroupSelector.vue'
import type { AdminGroup } from '@/types'

vi.mock('vue-i18n', async () => {
  const actual = await vi.importActual<typeof import('vue-i18n')>('vue-i18n')
  return {
    ...actual,
    useI18n: () => ({ t: (key: string) => key })
  }
})

const group = (id: number, name: string, domesticProvider = '', platform: AdminGroup['platform'] = 'openai') => ({
  id,
  name,
  description: null,
  platform,
  domestic_provider: domesticProvider,
  rate_multiplier: 1,
  account_count: 1
}) as AdminGroup

const GroupBadgeStub = defineComponent({
  props: { name: String },
  template: '<span data-test="group-name">{{ name }}</span>'
})

describe('GroupSelector domestic provider isolation', () => {
  it('shows only the matching domestic provider plus composite groups', () => {
    const wrapper = mount(GroupSelector, {
      props: {
        modelValue: [],
        platform: 'openai',
        domesticProvider: 'deepseek',
        groups: [
          group(1, 'OpenAI default'),
          group(2, 'DeepSeek', 'deepseek'),
          group(3, 'Qwen', 'qwen'),
          group(4, 'Composite', '', 'composite')
        ]
      },
      global: {
        stubs: { GroupBadge: GroupBadgeStub, Icon: true }
      }
    })

    const labels = wrapper.findAll('[data-test="group-name"]').map((node) => node.text())
    expect(labels).toEqual(['DeepSeek', 'Composite'])
  })

  it('keeps ordinary OpenAI accounts out of domestic groups', () => {
    const wrapper = mount(GroupSelector, {
      props: {
        modelValue: [],
        platform: 'openai',
        groups: [group(1, 'OpenAI default'), group(2, 'DeepSeek', 'deepseek')]
      },
      global: {
        stubs: { GroupBadge: GroupBadgeStub, Icon: true }
      }
    })

    expect(wrapper.findAll('[data-test="group-name"]').map((node) => node.text())).toEqual([
      'OpenAI default'
    ])
  })
})
