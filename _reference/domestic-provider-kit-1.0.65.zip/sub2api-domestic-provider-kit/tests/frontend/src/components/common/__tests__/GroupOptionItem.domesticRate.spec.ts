import { readFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

import { describe, expect, it } from "vitest";

const source = readFileSync(
  resolve(dirname(fileURLToPath(import.meta.url)), "../GroupOptionItem.vue"),
  "utf8",
);

describe("GroupOptionItem domestic rate display", () => {
  it("renders group × user and keeps the legacy replacement branch", () => {
    expect(source).toContain("hasDomesticUserFactor");
    expect(source).toContain(
      "(props.rateMultiplier ?? 1) * (props.userRateMultiplier ?? 1)",
    );
    expect(source).toContain('v-else-if="hasCustomRate"');
  });
});
