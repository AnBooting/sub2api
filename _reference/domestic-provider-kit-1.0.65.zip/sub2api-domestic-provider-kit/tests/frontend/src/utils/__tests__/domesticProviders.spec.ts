import { describe, expect, it } from 'vitest'
import {
  DOMESTIC_PROVIDERS,
  getDomesticProvider,
  normalizeDomesticProviderId
} from '@/utils/domesticProviders'

describe('domestic provider catalog', () => {
  it('keeps the account and group provider menu complete and stable', () => {
    expect(DOMESTIC_PROVIDERS.map((provider) => provider.id)).toEqual([
      'deepseek',
      'qwen',
      'doubao',
      'kimi',
      'zhipu',
      'minimax',
      'baichuan',
      'yi',
      'stepfun',
      'custom'
    ])
  })

  it('normalizes persisted provider IDs without inventing a gateway platform', () => {
    expect(getDomesticProvider(' QWEN ')?.label).toBe('通义千问')
    expect(normalizeDomesticProviderId('not-yet-supported')).toBe('custom')
  })

  it('defaults priced providers to their official international API scope', () => {
    const endpoints = Object.fromEntries(DOMESTIC_PROVIDERS.map((provider) => [provider.id, provider.baseUrl]))

    expect(endpoints.qwen).toBe('https://dashscope-intl.aliyuncs.com/compatible-mode/v1')
    expect(endpoints.doubao).toBe('https://ark.ap-southeast.bytepluses.com/api/v3')
    expect(endpoints.kimi).toBe('https://api.moonshot.ai/v1')
    expect(endpoints.zhipu).toBe('https://api.z.ai/api/paas/v4/')
    expect(endpoints.minimax).toBe('https://api.minimax.io/v1')
    expect(endpoints.stepfun).toBe('https://api.stepfun.ai/v1')
    expect(endpoints.baichuan).toBe('')
    expect(endpoints.yi).toBe('')
  })
})
