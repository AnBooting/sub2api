//go:build unit

package dto

import (
	"testing"

	"github.com/Wei-Shaw/sub2api/internal/service"
	"github.com/stretchr/testify/require"
)

func TestGroupFromServiceIncludesDomesticProviderWithoutChangingPlatform(t *testing.T) {
	group := GroupFromServiceAdmin(&service.Group{
		ID:               3,
		Platform:         service.PlatformOpenAI,
		DomesticProvider: service.DomesticProviderStepFun,
	})

	require.Equal(t, service.PlatformOpenAI, group.Platform)
	require.Equal(t, service.DomesticProviderStepFun, group.DomesticProvider)
}
