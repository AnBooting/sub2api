//go:build unit

package handler

import "testing"

func TestDomesticPricingWSRequestModelEveryTurnFallbackOrder(t *testing.T) {
	tests := []struct {
		name          string
		originalModel string
		payload       []byte
		fallbackModel string
		want          string
	}{
		{
			name:          "pre-transform original model wins",
			originalModel: " turn-alias ",
			payload:       []byte(`{"model":"already-transformed"}`),
			fallbackModel: "session-model",
			want:          "turn-alias",
		},
		{
			name:          "explicit payload model",
			payload:       []byte(`{"model":"turn-model"}`),
			fallbackModel: "session-model",
			want:          "turn-model",
		},
		{
			name:          "model-less subsequent turn uses session model",
			payload:       []byte(`{"type":"response.create"}`),
			fallbackModel: " session-model ",
			want:          "session-model",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := domesticPricingWSRequestModel(tt.originalModel, tt.payload, tt.fallbackModel); got != tt.want {
				t.Fatalf("domesticPricingWSRequestModel() = %q, want %q", got, tt.want)
			}
		})
	}
}
