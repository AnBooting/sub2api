//go:build unit

package service

import (
	"context"
	"errors"
	"testing"

	"github.com/stretchr/testify/require"
)

func TestNormalizeDomesticProvider(t *testing.T) {
	t.Parallel()

	for _, provider := range []string{
		"deepseek", "qwen", "doubao", "kimi", "zhipu", "minimax",
		"baichuan", "yi", "stepfun", "custom",
	} {
		got, err := NormalizeDomesticProvider(PlatformOpenAI, "  "+provider+"  ")
		require.NoError(t, err)
		require.Equal(t, provider, got)
	}

	got, err := NormalizeDomesticProvider(PlatformAnthropic, DomesticProviderMiniMax)
	require.NoError(t, err)
	require.Equal(t, DomesticProviderMiniMax, got)
	_, err = NormalizeDomesticProvider(PlatformGemini, DomesticProviderDeepSeek)
	require.ErrorContains(t, err, "requires openai or anthropic")
	_, err = NormalizeDomesticProvider(PlatformOpenAI, "unknown")
	require.ErrorContains(t, err, "unsupported")
}

func TestAdminServiceCreateGroupPersistsDomesticProviderOnOpenAIPlatform(t *testing.T) {
	repo := &groupRepoStubForAdmin{}
	svc := &adminServiceImpl{groupRepo: repo}

	created, err := svc.CreateGroup(context.Background(), &CreateGroupInput{
		Name:             "Qwen International",
		Platform:         PlatformOpenAI,
		DomesticProvider: DomesticProviderQwen,
		RateMultiplier:   1.2,
	})

	require.NoError(t, err)
	require.Equal(t, PlatformOpenAI, created.Platform)
	require.Equal(t, DomesticProviderQwen, created.DomesticProvider)
	require.Same(t, created, repo.created)
}

func TestAdminServiceUpdateGroupChangesDomesticProviderAndClearsOnPlatformMove(t *testing.T) {
	base := &Group{
		ID:                           8,
		Name:                         "domestic",
		Platform:                     PlatformOpenAI,
		DomesticProvider:             DomesticProviderDeepSeek,
		RateMultiplier:               1,
		Status:                       StatusActive,
		SubscriptionType:             SubscriptionTypeStandard,
		ImageRateMultiplier:          1,
		BatchImageDiscountMultiplier: .5,
		BatchImageHoldMultiplier:     .6,
		VideoRateMultiplier:          1,
		PeakRateMultiplier:           1,
	}
	repo := &groupRepoStubForAdmin{
		getByID: base,
		getAccountIDsByGroupIDsFn: func([]int64) ([]int64, error) {
			return nil, nil
		},
	}
	svc := &adminServiceImpl{groupRepo: repo}

	provider := DomesticProviderMiniMax
	updated, err := svc.UpdateGroup(context.Background(), base.ID, &UpdateGroupInput{
		DomesticProvider: &provider,
	})
	require.NoError(t, err)
	require.Equal(t, DomesticProviderMiniMax, updated.DomesticProvider)

	updated, err = svc.UpdateGroup(context.Background(), base.ID, &UpdateGroupInput{
		Platform: PlatformAnthropic,
	})
	require.NoError(t, err)
	require.Equal(t, DomesticProviderMiniMax, updated.DomesticProvider)
}

func TestAdminServiceUpdateGroupRejectsProviderChangeBeforeWritingWhenBoundAccountDiffers(t *testing.T) {
	base := &Group{
		ID:                           8,
		Name:                         "domestic",
		Platform:                     PlatformOpenAI,
		DomesticProvider:             DomesticProviderDeepSeek,
		RateMultiplier:               1,
		Status:                       StatusActive,
		SubscriptionType:             SubscriptionTypeStandard,
		ImageRateMultiplier:          1,
		BatchImageDiscountMultiplier: .5,
		BatchImageHoldMultiplier:     .6,
		VideoRateMultiplier:          1,
		PeakRateMultiplier:           1,
	}
	repo := &groupRepoStubForAdmin{
		getByID: base,
		getAccountIDsByGroupIDsFn: func(groupIDs []int64) ([]int64, error) {
			require.Equal(t, []int64{base.ID}, groupIDs)
			return []int64{31}, nil
		},
	}
	accountRepo := &accountRepoStubForBulkUpdate{getByIDsAccounts: []*Account{{
		ID:       31,
		Platform: PlatformOpenAI,
		Extra:    map[string]any{"domestic_provider": DomesticProviderDeepSeek},
	}}}
	svc := &adminServiceImpl{groupRepo: repo, accountRepo: accountRepo}

	provider := DomesticProviderQwen
	updated, err := svc.UpdateGroup(context.Background(), base.ID, &UpdateGroupInput{DomesticProvider: &provider})

	require.Nil(t, updated)
	require.ErrorContains(t, err, "DOMESTIC_PROVIDER_GROUP_MISMATCH")
	require.Nil(t, repo.updated, "group persistence must not run after compatibility failure")
	require.Zero(t, repo.atomicUpdateCalls)
}

func TestAdminServiceUpdateGroupValidatesCopySourceBeforeWriting(t *testing.T) {
	target := &Group{
		ID:                           8,
		Platform:                     PlatformOpenAI,
		DomesticProvider:             DomesticProviderQwen,
		RateMultiplier:               1,
		SubscriptionType:             SubscriptionTypeStandard,
		ImageRateMultiplier:          1,
		BatchImageDiscountMultiplier: .5,
		BatchImageHoldMultiplier:     .6,
		VideoRateMultiplier:          1,
		PeakRateMultiplier:           1,
	}
	repo := &groupRepoStubForAdmin{getByIDByID: map[int64]*Group{
		8:  target,
		11: {ID: 11, Platform: PlatformOpenAI, DomesticProvider: DomesticProviderDeepSeek},
	}}
	svc := &adminServiceImpl{groupRepo: repo}

	updated, err := svc.UpdateGroup(context.Background(), target.ID, &UpdateGroupInput{
		CopyAccountsFromGroupIDs: []int64{11},
	})

	require.Nil(t, updated)
	require.ErrorContains(t, err, "platform/provider mismatch")
	require.Nil(t, repo.updated, "plain group update must not run before copy validation")
	require.Zero(t, repo.atomicUpdateCalls)
}

func TestAdminServiceUpdateGroupUsesAtomicProviderAndBindingWrite(t *testing.T) {
	target := &Group{
		ID:                           8,
		Platform:                     PlatformOpenAI,
		DomesticProvider:             DomesticProviderQwen,
		RateMultiplier:               1,
		SubscriptionType:             SubscriptionTypeStandard,
		ImageRateMultiplier:          1,
		BatchImageDiscountMultiplier: .5,
		BatchImageHoldMultiplier:     .6,
		VideoRateMultiplier:          1,
		PeakRateMultiplier:           1,
	}
	repo := &groupRepoStubForAdmin{
		getByIDByID: map[int64]*Group{
			8:  target,
			12: {ID: 12, Platform: PlatformOpenAI, DomesticProvider: DomesticProviderQwen},
		},
		getAccountIDsByGroupIDsFn: func(groupIDs []int64) ([]int64, error) {
			require.Equal(t, []int64{12}, groupIDs)
			return []int64{32}, nil
		},
		updateWithAccountBindingsFn: func(group *Group, accountIDs []int64) error {
			require.Equal(t, target.ID, group.ID)
			require.Equal(t, []int64{32}, accountIDs)
			return errors.New("transaction rolled back")
		},
	}
	accountRepo := &accountRepoStubForBulkUpdate{getByIDsAccounts: []*Account{{
		ID:       32,
		Platform: PlatformOpenAI,
		Extra:    map[string]any{"domestic_provider": DomesticProviderQwen},
	}}}
	svc := &adminServiceImpl{groupRepo: repo, accountRepo: accountRepo}

	updated, err := svc.UpdateGroup(context.Background(), target.ID, &UpdateGroupInput{
		CopyAccountsFromGroupIDs: []int64{12},
	})

	require.Nil(t, updated)
	require.ErrorContains(t, err, "transaction rolled back")
	require.Nil(t, repo.updated, "plain non-atomic update path must remain unused")
	require.Equal(t, 1, repo.atomicUpdateCalls)
}

func TestAdminServiceCreateDomesticGroupRejectsCopyFromOtherProvider(t *testing.T) {
	repo := &groupRepoStubForAdmin{
		getByIDByID: map[int64]*Group{
			11: {ID: 11, Platform: PlatformOpenAI, DomesticProvider: DomesticProviderDeepSeek},
		},
	}
	svc := &adminServiceImpl{groupRepo: repo}

	_, err := svc.CreateGroup(context.Background(), &CreateGroupInput{
		Name:                     "qwen",
		Platform:                 PlatformOpenAI,
		DomesticProvider:         DomesticProviderQwen,
		RateMultiplier:           1,
		CopyAccountsFromGroupIDs: []int64{11},
	})
	require.ErrorContains(t, err, "platform mismatch")
}

func TestAdminServiceCreateDomesticGroupRejectsDirtySourceAccountBeforeAtomicCreate(t *testing.T) {
	repo := &groupRepoStubForAdmin{
		getByIDByID: map[int64]*Group{
			11: {ID: 11, Platform: PlatformOpenAI, DomesticProvider: DomesticProviderQwen},
		},
		getAccountIDsByGroupIDsFn: func([]int64) ([]int64, error) {
			return []int64{41}, nil
		},
	}
	accountRepo := &accountRepoStubForBulkUpdate{getByIDsAccounts: []*Account{{
		ID:       41,
		Platform: PlatformOpenAI,
		Extra:    map[string]any{"domestic_provider": DomesticProviderDeepSeek},
	}}}
	svc := &adminServiceImpl{groupRepo: repo, accountRepo: accountRepo}

	created, err := svc.CreateGroup(context.Background(), &CreateGroupInput{
		Name:                     "qwen",
		Platform:                 PlatformOpenAI,
		DomesticProvider:         DomesticProviderQwen,
		RateMultiplier:           1,
		CopyAccountsFromGroupIDs: []int64{11},
	})

	require.Nil(t, created)
	require.ErrorContains(t, err, "DOMESTIC_PROVIDER_GROUP_MISMATCH")
	require.Zero(t, repo.atomicCreateCalls)
}

func TestDomesticAccountGroupCompatibility(t *testing.T) {
	repo := &groupRepoStubForAdmin{getByIDByID: map[int64]*Group{
		1: {ID: 1, Platform: PlatformOpenAI, DomesticProvider: DomesticProviderDeepSeek},
		2: {ID: 2, Platform: PlatformOpenAI, DomesticProvider: DomesticProviderQwen},
		3: {ID: 3, Platform: PlatformComposite},
	}}
	svc := &adminServiceImpl{groupRepo: repo}

	require.NoError(t, svc.validateAccountDomesticGroups(
		context.Background(), PlatformOpenAI, DomesticProviderDeepSeek, []int64{1, 3},
	))
	err := svc.validateAccountDomesticGroups(
		context.Background(), PlatformOpenAI, DomesticProviderDeepSeek, []int64{2},
	)
	require.ErrorContains(t, err, "DOMESTIC_PROVIDER_GROUP_MISMATCH")
	err = svc.validateAccountDomesticGroups(
		context.Background(), PlatformOpenAI, "", []int64{1},
	)
	require.ErrorContains(t, err, "DOMESTIC_PROVIDER_GROUP_MISMATCH")

	anthropicRepo := &groupRepoStubForAdmin{getByIDByID: map[int64]*Group{
		4: {ID: 4, Platform: PlatformAnthropic, DomesticProvider: DomesticProviderMiniMax},
		5: {ID: 5, Platform: PlatformAnthropic, DomesticProvider: DomesticProviderKimi},
	}}
	anthropicSvc := &adminServiceImpl{groupRepo: anthropicRepo}
	require.NoError(t, anthropicSvc.validateAccountDomesticGroups(
		context.Background(), PlatformAnthropic, DomesticProviderMiniMax, []int64{4},
	))
	err = anthropicSvc.validateAccountDomesticGroups(
		context.Background(), PlatformAnthropic, DomesticProviderMiniMax, []int64{5},
	)
	require.ErrorContains(t, err, "DOMESTIC_PROVIDER_GROUP_MISMATCH")
}

func TestDomesticProviderFromAccountExtraRejectsUnknownProvider(t *testing.T) {
	provider, err := domesticProviderFromAccountExtra(PlatformOpenAI, map[string]any{
		"domestic_provider": "stepfun",
	})
	require.NoError(t, err)
	require.Equal(t, DomesticProviderStepFun, provider)

	_, err = domesticProviderFromAccountExtra(PlatformOpenAI, map[string]any{
		"domestic_provider": "invented",
	})
	require.ErrorContains(t, err, "INVALID_DOMESTIC_PROVIDER")

	provider, err = domesticProviderFromAccountExtra(PlatformAnthropic, map[string]any{
		"domestic_provider": DomesticProviderMiniMax,
	})
	require.NoError(t, err)
	require.Equal(t, DomesticProviderMiniMax, provider)
}

func TestUpdateAccountRejectsDomesticProviderChangeWhenExistingGroupsBelongToAnotherProvider(t *testing.T) {
	accountRepo := &accountRepoStubForBulkUpdate{getByIDAccounts: map[int64]*Account{
		7: {
			ID:       7,
			Platform: PlatformOpenAI,
			Type:     AccountTypeAPIKey,
			Status:   StatusActive,
			GroupIDs: []int64{1},
			Extra:    map[string]any{"domestic_provider": DomesticProviderDeepSeek},
		},
	}}
	groupRepo := &groupRepoStubForAdmin{getByIDByID: map[int64]*Group{
		1: {ID: 1, Platform: PlatformOpenAI, DomesticProvider: DomesticProviderDeepSeek},
	}}
	svc := &adminServiceImpl{accountRepo: accountRepo, groupRepo: groupRepo}

	updated, err := svc.UpdateAccount(context.Background(), 7, &UpdateAccountInput{
		Extra: map[string]any{"domestic_provider": DomesticProviderQwen},
	})

	require.Nil(t, updated)
	require.ErrorContains(t, err, "DOMESTIC_PROVIDER_GROUP_MISMATCH")
	require.Empty(t, accountRepo.updatedAccounts)
}
