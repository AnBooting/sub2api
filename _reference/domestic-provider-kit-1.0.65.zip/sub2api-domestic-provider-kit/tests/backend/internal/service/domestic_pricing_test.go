//go:build unit

package service

import (
	"context"
	"errors"
	"math"
	"testing"
	"time"

	"github.com/stretchr/testify/require"
)

type domesticPricingRepoStub struct {
	overrides map[string]DomesticPricingEntry
	err       error
	version   int64
}

func (r *domesticPricingRepoStub) ListOverrides(context.Context) ([]DomesticPricingEntry, error) {
	if r.err != nil {
		return nil, r.err
	}
	items := make([]DomesticPricingEntry, 0, len(r.overrides))
	for _, entry := range r.overrides {
		items = append(items, entry)
	}
	return items, nil
}

func (r *domesticPricingRepoStub) GetOverride(_ context.Context, provider, model string) (*DomesticPricingEntry, error) {
	if r.err != nil {
		return nil, r.err
	}
	entry, ok := r.overrides[domesticPricingKey(provider, model)]
	if !ok {
		return nil, nil
	}
	copy := entry
	return &copy, nil
}

func (r *domesticPricingRepoStub) UpsertOverride(_ context.Context, input DomesticPricingOverrideInput) (*DomesticPricingEntry, error) {
	if r.err != nil {
		return nil, r.err
	}
	if r.overrides == nil {
		r.overrides = make(map[string]DomesticPricingEntry)
	}
	r.version++
	entry := DomesticPricingEntry{
		Provider:                input.Provider,
		Model:                   input.Model,
		InputPricePerToken:      floatPtr(input.InputPricePerToken),
		OutputPricePerToken:     floatPtr(input.OutputPricePerToken),
		CacheReadPricePerToken:  input.CacheReadPricePerToken,
		CacheWritePricePerToken: input.CacheWritePricePerToken,
		Source:                  input.Source,
		Version:                 r.version,
		UpdatedAt:               time.Now(),
	}
	r.overrides[domesticPricingKey(input.Provider, input.Model)] = entry
	return &entry, nil
}

func (r *domesticPricingRepoStub) DeleteOverride(_ context.Context, provider, model string) (bool, error) {
	if r.err != nil {
		return false, r.err
	}
	key := domesticPricingKey(provider, model)
	if _, ok := r.overrides[key]; !ok {
		return false, nil
	}
	delete(r.overrides, key)
	return true, nil
}

func TestDomesticPricingResolveUsesExactProviderAndModel(t *testing.T) {
	svc := NewDomesticPricingService(nil)
	entry, err := svc.Resolve(context.Background(), " DeepSeek ", "DEEPSEEK-V4-PRO")
	require.NoError(t, err)
	require.Equal(t, "USD", entry.Currency)
	require.Equal(t, DomesticPricingStatusActive, entry.Status)
	require.InDelta(t, 4.5/1_000_000, *entry.InputPricePerToken, 1e-18)
	require.InDelta(t, 13.5/1_000_000, *entry.OutputPricePerToken, 1e-18)

	_, err = svc.Resolve(context.Background(), DomesticProviderQwen, "deepseek-v4-pro")
	require.ErrorIs(t, err, ErrDomesticPricingPending)

	_, err = svc.Resolve(context.Background(), DomesticProviderQwen, "gpt-5.4")
	require.ErrorIs(t, err, ErrDomesticPricingPending)
}

func TestDomesticPricingUsesMainlandNumericBasisAcrossProviders(t *testing.T) {
	svc := NewDomesticPricingService(nil)
	tests := []struct {
		provider, model          string
		input, output, cacheRead float64
	}{
		// v1.0.34: 改为国内官方标准价（1元=1美元数字直用），详见
		// domestic_pricing_china_standard_test.go 的完整守门用例。
		{DomesticProviderDeepSeek, "deepseek-flash", 1.00, 4.00, 0.02},
		{DomesticProviderQwen, "qwen-max", 11.52, 46.08, 0},
		{DomesticProviderDoubao, "skylark-pro", 2.88, 11.52, 0.576},
		{DomesticProviderKimi, "kimi-k2.5", 4.32, 21.60, 0.72},
		{DomesticProviderZhipu, "glm-5.3-flashx", 1.00, 3.20, 0.50},
		{DomesticProviderZhipu, "glm-5.3-flash", 0.80, 2.80, 0.23},
		{DomesticProviderZhipu, "glm-5.3", 8.00, 28.00, 2.00},
		{DomesticProviderZhipu, "glm-5.2", 8.00, 28.00, 2.00},
		{DomesticProviderZhipu, "glm-5.1", 8.00, 28.00, 2.00},
		{DomesticProviderMiniMax, "minimax-m2.7", 2.10, 8.40, 0.42},
		{DomesticProviderStepFun, "step-3.7-flash", 1.44, 8.28, 0.288},
	}
	for _, test := range tests {
		t.Run(test.provider+"/"+test.model, func(t *testing.T) {
			entry, err := svc.Resolve(context.Background(), test.provider, test.model)
			require.NoError(t, err)
			require.Equal(t, "USD", entry.Currency)
			require.InDelta(t, test.input/1_000_000, *entry.InputPricePerToken, 1e-18)
			require.InDelta(t, test.output/1_000_000, *entry.OutputPricePerToken, 1e-18)
			if test.cacheRead == 0 {
				require.Nil(t, entry.CacheReadPricePerToken)
			} else {
				require.InDelta(t, test.cacheRead/1_000_000, *entry.CacheReadPricePerToken, 1e-18)
			}
		})
	}
}

func TestDomesticPricingKimiK3UsesCurrentDomesticNumericRate(t *testing.T) {
	svc := NewDomesticPricingService(nil)
	entry, err := svc.Resolve(context.Background(), DomesticProviderKimi, "kimi-k3")
	require.NoError(t, err)
	require.InDelta(t, 20.0/1_000_000, *entry.InputPricePerToken, 1e-18)
	require.InDelta(t, 100.0/1_000_000, *entry.OutputPricePerToken, 1e-18)
	require.NotNil(t, entry.CacheReadPricePerToken)
	require.InDelta(t, 2.0/1_000_000, *entry.CacheReadPricePerToken, 1e-18)
}

func TestDomesticPricingPendingEntriesNeverExposeZeroAsPrice(t *testing.T) {
	svc := NewDomesticPricingService(nil)
	catalog, err := svc.ListCatalog(context.Background())
	require.NoError(t, err)

	pendingProviders := map[string]bool{}
	for _, entry := range catalog {
		if entry.Status != DomesticPricingStatusPending {
			continue
		}
		require.Nil(t, entry.InputPricePerToken, entry.Provider+"/"+entry.Model)
		require.Nil(t, entry.OutputPricePerToken, entry.Provider+"/"+entry.Model)
		pendingProviders[entry.Provider] = true
	}
	require.True(t, pendingProviders[DomesticProviderBaichuan])
	require.True(t, pendingProviders[DomesticProviderYi])
	require.True(t, pendingProviders[DomesticProviderCustom])

	_, err = svc.Resolve(context.Background(), DomesticProviderZhipu, "glm-4.7-flash")
	require.ErrorIs(t, err, ErrDomesticPricingPending)
}

func TestDomesticPricingOverrideWinsAndRejectsUnsafeValues(t *testing.T) {
	repo := &domesticPricingRepoStub{overrides: make(map[string]DomesticPricingEntry)}
	svc := NewDomesticPricingService(repo)
	input := 9.0 / 1_000_000
	output := 18.0 / 1_000_000
	entry, err := svc.UpsertOverride(context.Background(), DomesticPricingOverrideInput{
		Provider:            DomesticProviderQwen,
		Model:               "qwen-max",
		Source:              "https://www.alibabacloud.com/help/en/model-studio/model-pricing",
		InputPricePerToken:  input,
		OutputPricePerToken: output,
	})
	require.NoError(t, err)
	require.True(t, entry.Override)
	require.Equal(t, "USD", entry.Currency)

	resolved, err := svc.Resolve(context.Background(), DomesticProviderQwen, "qwen-max")
	require.NoError(t, err)
	require.InDelta(t, input, *resolved.InputPricePerToken, 1e-18)
	require.InDelta(t, output, *resolved.OutputPricePerToken, 1e-18)
	require.Equal(t, "https://www.alibabacloud.com/help/en/model-studio/model-pricing", resolved.Source)

	for _, bad := range []float64{0, -1, math.NaN(), math.Inf(1)} {
		_, err := svc.UpsertOverride(context.Background(), DomesticPricingOverrideInput{
			Provider: DomesticProviderQwen, Model: "unsafe", Source: "https://example.com/official-pricing", InputPricePerToken: bad, OutputPricePerToken: 1e-6,
		})
		require.ErrorIs(t, err, ErrDomesticPricingInvalid)
	}
	_, err = svc.UpsertOverride(context.Background(), DomesticPricingOverrideInput{
		Provider: DomesticProviderQwen, Model: "missing-source", InputPricePerToken: 1e-6, OutputPricePerToken: 2e-6,
	})
	require.ErrorIs(t, err, ErrDomesticPricingInvalid)
}

func TestDomesticPricingRepositoryFailureIsFailClosed(t *testing.T) {
	svc := NewDomesticPricingService(&domesticPricingRepoStub{err: errors.New("db unavailable")})
	_, err := svc.Resolve(context.Background(), DomesticProviderDeepSeek, "deepseek-v4-pro")
	require.ErrorIs(t, err, ErrDomesticPricingUnavailable)
}

func TestDomesticPricingMiniMaxM3CarriesOfficialLongContextTier(t *testing.T) {
	svc := NewDomesticPricingService(nil)
	entry, err := svc.Resolve(context.Background(), DomesticProviderMiniMax, "MiniMax-M3")
	require.NoError(t, err)
	require.Equal(t, 512_000, entry.LongContextInputThreshold)
	require.Equal(t, 2.0, entry.LongContextInputMultiplier)
	require.Equal(t, 2.0, entry.LongContextOutputMultiplier)
}

func TestDomesticPricingDeepSeekPeakWindows(t *testing.T) {
	tests := []struct {
		name string
		at   time.Time
		peak bool
	}{
		{name: "weekday before morning peak", at: time.Date(2026, 9, 11, 8, 59, 59, 0, time.FixedZone("CST", 8*60*60))},
		{name: "weekday morning start", at: time.Date(2026, 9, 11, 9, 0, 0, 0, time.FixedZone("CST", 8*60*60)), peak: true},
		{name: "weekday lunch start", at: time.Date(2026, 9, 11, 12, 0, 0, 0, time.FixedZone("CST", 8*60*60))},
		{name: "weekday afternoon start", at: time.Date(2026, 9, 11, 14, 0, 0, 0, time.FixedZone("CST", 8*60*60)), peak: true},
		{name: "weekday afternoon end", at: time.Date(2026, 9, 11, 18, 0, 0, 0, time.FixedZone("CST", 8*60*60))},
		{name: "weekend daytime", at: time.Date(2026, 9, 12, 10, 0, 0, 0, time.FixedZone("CST", 8*60*60))},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			require.Equal(t, test.peak, isDeepSeekPeakTime(test.at, DomesticProviderDeepSeek))
		})
	}
}

func TestDomesticPricingDeepSeekBillingAppliesPeakRateToBuiltInsOnly(t *testing.T) {
	peakTime := time.Date(2026, 9, 11, 10, 0, 0, 0, time.FixedZone("CST", 8*60*60))
	builtInService := NewDomesticPricingService(nil)
	builtInService.now = func() time.Time { return peakTime }
	builtIn, err := builtInService.Resolve(context.Background(), DomesticProviderDeepSeek, "deepseek-v4.1-flash")
	require.NoError(t, err)
	builtInPricing, err := builtInService.modelPricing(builtIn)
	require.NoError(t, err)
	require.InDelta(t, 2.0/1_000_000, builtInPricing.InputPricePerToken, 1e-18)
	require.InDelta(t, 8.0/1_000_000, builtInPricing.OutputPricePerToken, 1e-18)
	require.InDelta(t, 0.04/1_000_000, builtInPricing.CacheReadPricePerToken, 1e-18)

	override := DomesticPricingEntry{
		Provider: DomesticProviderDeepSeek, Model: "deepseek-flash",
		InputPricePerToken: floatPtr(3e-6), OutputPricePerToken: floatPtr(9e-6),
		Source: "https://example.com/pricing", Status: DomesticPricingStatusActive,
		Override: true, PeakRateMultiplier: 2,
	}
	overridePricing, err := builtInService.modelPricing(&override)
	require.NoError(t, err)
	require.InDelta(t, 3e-6, overridePricing.InputPricePerToken, 1e-18)
	require.InDelta(t, 9e-6, overridePricing.OutputPricePerToken, 1e-18)
}
