//go:build unit

package service

import (
	"context"
	"testing"
	"time"

	"github.com/stretchr/testify/require"
)

func TestModelPricingResolverDomesticScopeBypassesGenericFallback(t *testing.T) {
	bs := newTestBillingServiceForResolver()
	bs.fallbackPrices["gpt-5.4"] = &ModelPricing{
		InputPricePerToken:  2.5e-6,
		OutputPricePerToken: 15e-6,
	}
	resolver := NewModelPricingResolver(nil, bs)
	resolver.SetDomesticPricingService(NewDomesticPricingService(nil))

	resolved := resolver.Resolve(context.Background(), PricingInput{
		Model:            "gpt-5.4",
		DomesticProvider: DomesticProviderQwen,
	})
	require.NotNil(t, resolved)
	require.Nil(t, resolved.BasePricing)
	require.Equal(t, PricingSourceDomesticPending, resolved.Source)
	require.ErrorIs(t, resolved.Err, ErrDomesticPricingPending)

	_, err := bs.CalculateCostUnified(CostInput{
		Ctx:              context.Background(),
		Model:            "gpt-5.4",
		DomesticProvider: DomesticProviderQwen,
		Tokens:           UsageTokens{InputTokens: 1000, OutputTokens: 100},
		RateMultiplier:   1,
		Resolver:         resolver,
	})
	require.ErrorIs(t, err, ErrDomesticPricingPending)
}

func TestCalculateCostUnifiedDomesticWithoutResolverFailsClosed(t *testing.T) {
	bs := newTestBillingServiceForResolver()
	_, err := bs.CalculateCostUnified(CostInput{
		Model:            "claude-sonnet-4",
		DomesticProvider: DomesticProviderCustom,
		Tokens:           UsageTokens{InputTokens: 100},
		RateMultiplier:   1,
	})
	require.ErrorIs(t, err, ErrDomesticPricingUnavailable)
}

func TestModelPricingResolverDomesticNumericPriceCalculatesWithWebsiteCurrency(t *testing.T) {
	bs := newTestBillingServiceForResolver()
	resolver := NewModelPricingResolver(nil, bs)
	pricingService := NewDomesticPricingService(nil)
	pricingService.now = func() time.Time {
		return time.Date(2026, 9, 11, 13, 0, 0, 0, time.FixedZone("CST", 8*60*60))
	}
	resolver.SetDomesticPricingService(pricingService)

	cost, err := bs.CalculateCostUnified(CostInput{
		Ctx:              context.Background(),
		Model:            "deepseek-v4-pro",
		DomesticProvider: DomesticProviderDeepSeek,
		Tokens:           UsageTokens{InputTokens: 1_000_000, OutputTokens: 1_000_000},
		RateMultiplier:   1,
		Resolver:         resolver,
	})
	require.NoError(t, err)
	// The site keeps USD as its accounting currency, while domestic-provider
	// catalog values retain the official mainland numeric basis (v1.0.34:
	// DeepSeek v4-pro off-peak tier 4.5/13.5 per million tokens).
	require.InDelta(t, 4.5, cost.InputCost, 1e-12)
	require.InDelta(t, 13.5, cost.OutputCost, 1e-12)
	require.InDelta(t, 18.0, cost.ActualCost, 1e-12)
}

func TestModelPricingResolverDeepSeekPeakPriceCalculatesWithWebsiteCurrency(t *testing.T) {
	bs := newTestBillingServiceForResolver()
	resolver := NewModelPricingResolver(nil, bs)
	pricingService := NewDomesticPricingService(nil)
	pricingService.now = func() time.Time {
		return time.Date(2026, 9, 11, 10, 0, 0, 0, time.FixedZone("CST", 8*60*60))
	}
	resolver.SetDomesticPricingService(pricingService)

	cost, err := bs.CalculateCostUnified(CostInput{
		Ctx:              context.Background(),
		Model:            "deepseek-v4.1-flash",
		DomesticProvider: DomesticProviderDeepSeek,
		Tokens: UsageTokens{
			InputTokens:     1_000_000,
			OutputTokens:    1_000_000,
			CacheReadTokens: 1_000_000,
		},
		RateMultiplier: 1,
		Resolver:       resolver,
	})
	require.NoError(t, err)
	require.InDelta(t, 2.0, cost.InputCost, 1e-12)
	require.InDelta(t, 8.0, cost.OutputCost, 1e-12)
	require.InDelta(t, 0.04, cost.CacheReadCost, 1e-12)
	require.InDelta(t, 10.04, cost.ActualCost, 1e-12)
}

func TestOpenAIGatewayDomesticPricingPreflight(t *testing.T) {
	resolver := NewModelPricingResolver(nil, newTestBillingServiceForResolver())
	resolver.SetDomesticPricingService(NewDomesticPricingService(nil))
	svc := &OpenAIGatewayService{resolver: resolver}
	apiKey := &APIKey{Group: &Group{ID: 99, DomesticProvider: DomesticProviderQwen}}

	require.NoError(t, svc.ValidateDomesticModelPricing(context.Background(), apiKey, "qwen-max"))
	require.ErrorIs(t, svc.ValidateDomesticModelPricing(context.Background(), apiKey, "gpt-5.4"), ErrDomesticPricingPending)

	apiKey.Group.DomesticProvider = ""
	require.NoError(t, svc.ValidateDomesticModelPricing(context.Background(), apiKey, "gpt-5.4"))
}

func TestOpenAIGatewayDomesticPricingPreflightUsesSelectedAccountMapping(t *testing.T) {
	resolver := NewModelPricingResolver(nil, newTestBillingServiceForResolver())
	resolver.SetDomesticPricingService(NewDomesticPricingService(nil))
	svc := &OpenAIGatewayService{resolver: resolver}
	apiKey := &APIKey{Group: &Group{ID: 99, DomesticProvider: DomesticProviderQwen}}
	account := &Account{Credentials: map[string]any{
		"model_mapping": map[string]any{"public-alias": "qwen-max"},
	}}

	// The public alias itself is deliberately absent from the provider catalog.
	// It becomes billable only after this selected account's mapping is applied.
	require.ErrorIs(t, svc.ValidateDomesticModelPricing(context.Background(), apiKey, "public-alias"), ErrDomesticPricingPending)
	require.NoError(t, svc.ValidateDomesticModelPricingForAccount(context.Background(), apiKey, account, "public-alias", "", false))

	account.Credentials = map[string]any{
		"model_mapping": map[string]any{"public-alias": "unpriced-upstream-model"},
	}
	require.ErrorIs(
		t,
		svc.ValidateDomesticModelPricingForAccount(context.Background(), apiKey, account, "public-alias", "", false),
		ErrDomesticPricingPending,
	)
}

func TestModelPricingResolverDomesticAllowsOnlyExactPositiveChannelOverride(t *testing.T) {
	t.Run("exact positive override", func(t *testing.T) {
		resolver := newResolverWithChannel(t, []ChannelModelPricing{{
			Platform:    PlatformAnthropic,
			Models:      []string{"private-qwen-model"},
			BillingMode: BillingModeToken,
			InputPrice:  testPtrFloat64(1e-6),
			OutputPrice: testPtrFloat64(3e-6),
		}})
		resolver.SetDomesticPricingService(NewDomesticPricingService(nil))

		resolved := resolver.Resolve(context.Background(), PricingInput{
			Model: "private-qwen-model", GroupID: groupIDPtr(), DomesticProvider: DomesticProviderQwen,
		})
		require.NoError(t, resolved.Err)
		require.Equal(t, PricingSourceChannel, resolved.Source)
		require.InDelta(t, 1e-6, resolved.BasePricing.InputPricePerToken, 1e-18)
		require.InDelta(t, 3e-6, resolved.BasePricing.OutputPricePerToken, 1e-18)
	})

	t.Run("zero override is rejected", func(t *testing.T) {
		resolver := newResolverWithChannel(t, []ChannelModelPricing{{
			Platform:    PlatformAnthropic,
			Models:      []string{"private-qwen-model"},
			BillingMode: BillingModeToken,
			InputPrice:  testPtrFloat64(0),
			OutputPrice: testPtrFloat64(3e-6),
		}})
		resolver.SetDomesticPricingService(NewDomesticPricingService(nil))

		resolved := resolver.Resolve(context.Background(), PricingInput{
			Model: "private-qwen-model", GroupID: groupIDPtr(), DomesticProvider: DomesticProviderQwen,
		})
		require.ErrorIs(t, resolved.Err, ErrDomesticPricingInvalid)
	})
}
