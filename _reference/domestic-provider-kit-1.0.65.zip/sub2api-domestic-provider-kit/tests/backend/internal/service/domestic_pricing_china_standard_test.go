//go:build unit

package service

import (
	"context"
	"testing"

	"github.com/stretchr/testify/require"
)

// TestDomesticPricingChinaStandardRates v1.0.34 守门：目录价格必须与国内官方
// 标准价一致（站点货币 1元=1美元，数字直用）。来源：
//   - DeepSeek api-docs.deepseek.com 中文站（目录为谷价，计费按官方时段切峰价）
//   - Kimi platform.kimi.com
//   - MiniMax platform.minimaxi.com 按量计费页
//   - 智谱 docs.z.ai 官方牌价（国内人民币数字与国际 USD 数字 1:1 镜像）
//
// 任何人调整这些数字都必须同步更新本测试，防止"顺手改错价"。
func TestDomesticPricingChinaStandardRates(t *testing.T) {
	type expected struct {
		model      string
		input      float64 // 每百万 token
		output     float64
		cacheRead  float64
		cacheWrite float64
	}
	providerCases := map[string][]expected{
		DomesticProviderDeepSeek: {
			{model: "deepseek-v4-pro", input: 4.5, output: 13.5, cacheRead: 0.15},
			{model: "deepseek-flash", input: 1, output: 4, cacheRead: 0.02},
		},
		DomesticProviderKimi: {
			{model: "kimi-k3", input: 20, output: 100, cacheRead: 2},
			{model: "kimi-k2.7-code", input: 6.5, output: 27, cacheRead: 1.3},
			{model: "kimi-k2.7-code-highspeed", input: 13, output: 54, cacheRead: 2.6},
		},
		DomesticProviderZhipu: {
			// open.bigmodel.cn/pricing 国内官方价（Flash 为牌价，未按两周 5 折促销）。
			{model: "glm-5.3", input: 8, output: 28, cacheRead: 2},
			{model: "glm-5.3-flash", input: 0.8, output: 2.8, cacheRead: 0.23},
			{model: "glm-5.2", input: 8, output: 28, cacheRead: 2},
		},
		DomesticProviderMiniMax: {
			{model: "minimax-m3", input: 2.1, output: 8.4, cacheRead: 0.42},
			{model: "minimax-m2.7", input: 2.1, output: 8.4, cacheRead: 0.42, cacheWrite: 2.625},
			{model: "minimax-m2.7-highspeed", input: 4.2, output: 16.8, cacheRead: 0.42, cacheWrite: 2.625},
			{model: "minimax-m2.5", input: 2.1, output: 8.4, cacheRead: 0.21, cacheWrite: 2.625},
			{model: "minimax-m2.5-highspeed", input: 4.2, output: 16.8, cacheRead: 0.21, cacheWrite: 2.625},
			// 补缺条目：历史模型官方在售价。
			{model: "minimax-m2.1", input: 2.1, output: 8.4, cacheRead: 0.21, cacheWrite: 2.625},
			{model: "minimax-m2.1-highspeed", input: 4.2, output: 16.8, cacheRead: 0.21, cacheWrite: 2.625},
			{model: "minimax-m2", input: 2.1, output: 8.4, cacheRead: 0.21, cacheWrite: 2.625},
		},
	}

	svc := NewDomesticPricingService(nil)
	for provider, cases := range providerCases {
		for _, c := range cases {
			entry, err := svc.Resolve(context.Background(), provider, c.model)
			require.NoError(t, err, provider+"/"+c.model)
			require.InDelta(t, c.input/1_000_000, *entry.InputPricePerToken, 1e-15, provider+"/"+c.model)
			require.InDelta(t, c.output/1_000_000, *entry.OutputPricePerToken, 1e-15, provider+"/"+c.model)
			if c.cacheRead > 0 {
				require.NotNil(t, entry.CacheReadPricePerToken, provider+"/"+c.model)
				require.InDelta(t, c.cacheRead/1_000_000, *entry.CacheReadPricePerToken, 1e-15, provider+"/"+c.model)
			}
			if c.cacheWrite > 0 {
				require.NotNil(t, entry.CacheWritePricePerToken, provider+"/"+c.model)
				require.InDelta(t, c.cacheWrite/1_000_000, *entry.CacheWritePricePerToken, 1e-15, provider+"/"+c.model)
			}
		}
	}
}

// TestDomesticPricingAliasK3ResolvesKimiK3Rate v1.0.34 别名收口：
// kimi 命名空间内 k3 与 kimi-k3 必须解析到同一价格（别名收口在 domestic 目录，
// 不再依赖 channel 层硬编码）。
func TestDomesticPricingAliasK3ResolvesKimiK3Rate(t *testing.T) {
	svc := NewDomesticPricingService(nil)
	canonical, err := svc.Resolve(context.Background(), DomesticProviderKimi, "kimi-k3")
	require.NoError(t, err)
	aliased, err := svc.Resolve(context.Background(), DomesticProviderKimi, "k3")
	require.NoError(t, err)
	require.InDelta(t, *canonical.InputPricePerToken, *aliased.InputPricePerToken, 1e-18)
	require.InDelta(t, *canonical.OutputPricePerToken, *aliased.OutputPricePerToken, 1e-18)
}

func TestDomesticPricingDeepSeekDatedGroupModelsReuseV4Rates(t *testing.T) {
	svc := NewDomesticPricingService(nil)
	tests := []struct {
		alias, canonical         string
		input, output, cacheRead float64
	}{
		{alias: "deepseek-v4-pro-0813", canonical: "deepseek-v4-pro", input: 4.5, output: 13.5, cacheRead: 0.15},
		{alias: "deepseek-v4.1-flash", canonical: "deepseek-flash", input: 1, output: 4, cacheRead: 0.02},
		{alias: "deepseek-v4.1-flash-0910", canonical: "deepseek-flash", input: 1, output: 4, cacheRead: 0.02},
		{alias: "deepseek-v4-1-flash", canonical: "deepseek-flash", input: 1, output: 4, cacheRead: 0.02},
		{alias: "deepseek-v4-flash", canonical: "deepseek-flash", input: 1, output: 4, cacheRead: 0.02},
		{alias: "deepseek-v4-flash-0731", canonical: "deepseek-flash", input: 1, output: 4, cacheRead: 0.02},
		{alias: "deepseek-v4-flash-vision", canonical: "deepseek-flash", input: 1, output: 4, cacheRead: 0.02},
		{alias: "deepseek-v4-flash-vision-exp", canonical: "deepseek-flash", input: 1, output: 4, cacheRead: 0.02},
		{alias: "deepseek-ai/DeepSeek-V4-Flash-Vision-Exp", canonical: "deepseek-flash", input: 1, output: 4, cacheRead: 0.02},
		{alias: "deepseek-chat", canonical: "deepseek-flash", input: 1, output: 4, cacheRead: 0.02},
		{alias: "deepseek-reasoner", canonical: "deepseek-flash", input: 1, output: 4, cacheRead: 0.02},
		{alias: "deepseek-v3.2", canonical: "deepseek-flash", input: 1, output: 4, cacheRead: 0.02},
	}

	for _, test := range tests {
		t.Run(test.alias, func(t *testing.T) {
			canonical, err := svc.Resolve(context.Background(), DomesticProviderDeepSeek, test.canonical)
			require.NoError(t, err)
			aliased, err := svc.Resolve(context.Background(), DomesticProviderDeepSeek, test.alias)
			require.NoError(t, err)
			require.Equal(t, test.canonical, aliased.Model)
			require.InDelta(t, *canonical.InputPricePerToken, *aliased.InputPricePerToken, 1e-18)
			require.InDelta(t, *canonical.OutputPricePerToken, *aliased.OutputPricePerToken, 1e-18)
			require.InDelta(t, test.cacheRead/1_000_000, *aliased.CacheReadPricePerToken, 1e-18)
		})
	}
}
