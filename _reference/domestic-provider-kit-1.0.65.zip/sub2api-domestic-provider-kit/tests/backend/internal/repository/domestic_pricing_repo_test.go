//go:build unit

package repository

import (
	"context"
	"database/sql"
	"regexp"
	"testing"
	"time"

	"github.com/DATA-DOG/go-sqlmock"
	"github.com/Wei-Shaw/sub2api/internal/service"
	"github.com/stretchr/testify/require"
)

func TestDomesticPricingRepositoryGetMissingOverride(t *testing.T) {
	db, mock, err := sqlmock.New()
	require.NoError(t, err)
	defer db.Close()
	repo := NewDomesticPricingRepository(db)

	mock.ExpectQuery("SELECT .* FROM domestic_model_pricing_overrides").
		WithArgs("qwen", "missing").
		WillReturnError(sql.ErrNoRows)
	entry, err := repo.GetOverride(context.Background(), "qwen", "missing")
	require.NoError(t, err)
	require.Nil(t, entry)
	require.NoError(t, mock.ExpectationsWereMet())
}

func TestDomesticPricingRepositoryUpsertReturnsAuditableRevision(t *testing.T) {
	db, mock, err := sqlmock.New()
	require.NoError(t, err)
	defer db.Close()
	repo := NewDomesticPricingRepository(db)

	updatedAt := time.Date(2026, time.August, 9, 1, 2, 3, 0, time.UTC)
	columns := []string{
		"provider", "model", "input_price_per_token", "output_price_per_token",
		"cache_read_price_per_token", "cache_write_price_per_token", "source", "version", "updated_at",
	}
	mock.ExpectQuery(regexp.QuoteMeta("INSERT INTO domestic_model_pricing_overrides")).
		WithArgs("qwen", "private-qwen", 1e-6, 3e-6, nil, nil, "https://www.alibabacloud.com/help/en/model-studio/model-pricing").
		WillReturnRows(sqlmock.NewRows(columns).AddRow("qwen", "private-qwen", 1e-6, 3e-6, nil, nil, "https://www.alibabacloud.com/help/en/model-studio/model-pricing", int64(4), updatedAt))

	entry, err := repo.UpsertOverride(context.Background(), service.DomesticPricingOverrideInput{
		Provider: "qwen", Model: "private-qwen", Source: "https://www.alibabacloud.com/help/en/model-studio/model-pricing", InputPricePerToken: 1e-6, OutputPricePerToken: 3e-6,
	})
	require.NoError(t, err)
	require.Equal(t, int64(4), entry.Version)
	require.Equal(t, "https://www.alibabacloud.com/help/en/model-studio/model-pricing", entry.Source)
	require.True(t, entry.Override)
	require.InDelta(t, 1e-6, *entry.InputPricePerToken, 1e-18)
	require.NoError(t, mock.ExpectationsWereMet())
}
