package migrations

import (
	"strings"
	"testing"
)

func TestGroupDomesticProviderMigrationIsEmbeddedAndIdempotent(t *testing.T) {
	data, err := FS.ReadFile("196_group_domestic_provider.sql")
	if err != nil {
		t.Fatal(err)
	}
	sql := string(data)
	for _, required := range []string{
		"ADD COLUMN IF NOT EXISTS domestic_provider",
		"NOT NULL DEFAULT ''",
		"CHECK (domestic_provider = '' OR platform = 'openai')",
		"CREATE INDEX IF NOT EXISTS idx_groups_domestic_provider_active",
	} {
		if !strings.Contains(sql, required) {
			t.Fatalf("migration missing %q", required)
		}
	}
}

func TestGroupDomesticProviderAllowListUpgradeMigrationIsEmbedded(t *testing.T) {
	data, err := FS.ReadFile("198_group_domestic_provider_constraint.sql")
	if err != nil {
		t.Fatal(err)
	}
	sql := string(data)
	for _, required := range []string{
		"unsupported domestic_provider/platform scopes",
		"RAISE EXCEPTION",
		"quote_literal(domestic_provider)",
		"DROP CONSTRAINT IF EXISTS groups_domestic_provider_platform_check",
		"ADD CONSTRAINT groups_domestic_provider_platform_check",
		"domestic_provider IN (",
		"'deepseek', 'qwen', 'doubao', 'kimi', 'zhipu'",
		"'minimax', 'baichuan', 'yi', 'stepfun', 'custom'",
		"AND (domestic_provider = '' OR platform = 'openai')",
	} {
		if !strings.Contains(sql, required) {
			t.Fatalf("upgrade migration missing %q", required)
		}
	}
}

func TestDomesticPricingMigrationPreflightsPartialSchemas(t *testing.T) {
	data, err := FS.ReadFile("197_domestic_model_pricing_overrides.sql")
	if err != nil {
		t.Fatal(err)
	}
	sql := string(data)
	for _, required := range []string{
		"information_schema.columns",
		"pg_constraint",
		"missing columns",
		"missing constraints",
		"domestic_model_pricing_input_positive_check",
		"domestic_model_pricing_output_positive_check",
	} {
		if !strings.Contains(sql, required) {
			t.Fatalf("pricing migration preflight missing %q", required)
		}
	}
}
